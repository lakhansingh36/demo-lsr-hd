<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>:: Royal Market - Home ::</title>
<?php include("inc/top-script.php"); ?>
</head>
<body>
<?php include("inc/top-section.php"); ?>
<div class="content-wrap" data-effect="lnl-push"> 
<?php include("inc/header.php"); ?>
<?php include("inc/nav.php"); ?>
<?php include("inc/banner.php"); ?>
<div class="middle-se"> 
<?php include("inc/c2a1.php"); ?>
<?php include("inc/index-product1.php"); ?>

<?php include("inc/ad-box.php"); ?>

<?php include("inc/index-product2.php"); ?>
<?php include("inc/c2a2.php"); ?>

<?php include("inc/index-aboutus.php"); ?>

</div>
<?php include("inc/footer.php"); ?>
</div>
<a href="#0" class="cd-top"></a> 
<?php include("inc/footer-script.php"); ?>
</body>
</html>