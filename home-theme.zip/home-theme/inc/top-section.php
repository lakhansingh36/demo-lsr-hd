<div class="top-sec">
<nav class="navbar navbar-static-top line-navbar-one">
<div class="container">
<div class="navbar-header"> 
<button type="button" class="navbar-toggle collapsed ion-android-menu" data-toggle="collapse" data-target="#line-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="fa fa-ellipsis-v"></span> </button>
<button class="lno-btn-toggle"> <span class="fa fa-bars"></span> </button>
</div>
    
<div class="row">
<div class="col-sm-4 welcome-msg hidden-xs">Welcome to our Home Decorz Store!!!</div>
<div class="col-sm-8 collapse navbar-collapse navbar-right" id="line-navbar-collapse-1">
<ul class="nav navbar-nav top-menu">
<li><a href="compare-list.html">Compare list</a></li>
<li><a href="compare-list.html">Compare list</a></li>
<li><a href="mailto:rajeevrawat@gmail.com">rajeevrawat@gmail.com</a></li>
<li> <a href="#" class="btn btn-block btn-facebook" ><i class="ion-social-facebook"></i></a> </li>
<li> <a href="#" class="btn btn-block btn-twitter"><i class="ion-social-twitter"></i></a></li>
<li> <a href="#" class="btn btn-block btn-google"><i class="ion-social-google"></i></a></li>
</ul>
</div>
</div>
</div>
</nav>
<div class="line-navbar-left">
<p class="lnl-nav-title">Categories</p>
<ul class="lnl-nav">
</ul>
</div>
</div>
