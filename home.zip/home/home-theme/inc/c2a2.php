<div id="parallax" class="" data-speed="4">
 <section class="container">
 <div class="row">
 <div class="subscribe col-sm-12">
 <h3><span>Full of Heritage</span> <small>Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus</small> </h3>
 <div class="subscribe-icn"> <a class="btn btn-primary hvr-underline-from-center-primary" href="#">Collections</a> </div>
 </div>
 </div>
 </section>
 </div>