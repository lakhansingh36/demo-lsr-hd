<section class="container">
<div class="row">
<div class="col-sm-12 col-md-4 ad-box-outer">
<div class="small-ad">
<figure class="effect-layla"><img class="img-responsive" src="media/ad-box-1.jpg" width="370" height="200" alt=""/>
<figcaption>
<h3><span>Latest</span> Furniture</h3>
<p>Maecenas nec odio et ante tincidunt tempus </p>
<span class="start-price hvr-underline-from-center-primary">View Collection</span> </figcaption>
</figure>
</div>
</div>
        
<div class="col-sm-12 col-md-4 ad-box-outer">
<div class="small-ad">
<figure class="effect-layla"><img class="img-responsive" src="media/ad-box-2.jpg" width="370" height="200" alt=""/>
<figcaption>
<h3><span>Latest</span> Home Decor</h3>
 <p>Maecenas nec odio et ante tincidunt tempus </p>
<span class="start-price hvr-underline-from-center-primary">View Collection</span> </figcaption>
</figure>
</div>
</div>

<div class="col-sm-12 col-md-4 ad-box-outer">
<div class="small-ad">
<figure class="effect-layla"><img class="img-responsive" src="media/ad-box-3.jpg" width="370" height="200" alt=""/>
<figcaption>
<h3><span>Vintage</span> collection</h3>
<p>Maecenas nec odio et ante tincidunt tempus </p>
<span class="start-price hvr-underline-from-center-primary">View Collection</span> </figcaption>
</figure>
</div>
</div>
</div>
</section>