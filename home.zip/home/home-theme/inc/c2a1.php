<section class="container">
 <div class="row">
 <div class="col-sm-12 wide-ad">
 <figure class="effect-layla"> <img class="img-responsive hidden-xs" src="images/wide-ad-img.gif" width="1920" height="275" alt=""/>
 <img class="img-responsive visible-xs" src="images/wide-ad-img-small.png" width="1920" height="275" alt=""/>
 <figcaption>
 <h2>Home Decor <span>With</span> Meaning</h2>
 <p>Check Our Largest Collection of Furniture & Home Decor Products</p>
 <a href="#">View more</a> </figcaption>
 </figure>
 </div>
 </div>
 </section>