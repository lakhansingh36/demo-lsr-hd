<div id="banner">
<div class="item"> <img class="img-responsive hidden-xs" src="media/banner-img-1.jpg" width="1920" height="550" alt=""/>
<img class="img-responsive visible-xs" src="media/banner-img-1.jpg" width="1920" height="550" alt=""/>
<div class="slider-caption">
<div class="container">
<div class="row">
<div class="col-xs-12 col-sm-8 col-lg-6 caption-body">
<h2 class="title fadeInDownBig wow" >Home Décor</h2>
<h1 class="title fadeInDownBig wow"> Latest Furniture Collections</h1>
<p class="subtitle col-sm-9 fadeInUp wow hidden-xs">Donec pede justo fringilla vel aliquet nec vulputate eget arcu. In enim justo rhoncus ut imperdiet a venenatis vitae dictum felis eu pede mollis pretium integer tincidunt</p>
<div class="clearfix"></div>
<a class="btn btn-primary fadeInUp wow hvr-underline-from-center-primary hidden-xs" href="#"> <i class="rm-icon ion-android-checkmark-circle"></i> <span>Discover More</span> </a> <a class="btn btn-default fadeInUp wow hvr-underline-from-center-default hidden-xs" href="#"> <i class="rm-icon ion-android-star"></i> <span>All Collections</span> </a> </div>
</div>
</div>
</div>
</div>
    
    
<div class="item"> <img class="img-responsive hidden-xs" src="media/banner-img-2.jpg" width="1920" height="540" alt=""/>
<img class="img-responsive visible-xs" src="media/banner-img-2.jpg" width="1920" height="540" alt=""/>
<div class="slider-caption">
<div class="container">
<div class="row">
<div class="col-xs-12 col-sm-8 col-lg-6 caption-body">
<h2 data-animation="fadeInLeft" class="title fadeInDownBig text-primary" style="color:#FFF;">Furniture</h2>
<h1 data-animation="fadeInDownBig" class="title fadeInDownBig text-primary" style="color:#FFF;">THE NEW COLLECTION</h1>
<p data-animation="fadeInUp" class="subtitle col-sm-9  fadeInUp text-primary hidden-xs" style="color:#FFF;">Donec pede justo fringilla vel aliquet nec vulputate eget arcu. In enim justo rhoncus ut imperdiet a venenatis vitae dictum felis eu pede mollis pretium integer tincidunt</p>
<div class="clearfix"></div>
<a data-animation="fadeIn" class="btn btn-primary  fadeInUp hvr-underline-from-center-primary hidden-xs" href="#"> <i class="rm-icon ion-android-checkmark-circle"></i> <span>Discover More</span> </a> <a data-animation="fadeIn" class="btn btn-default fadeInUp hvr-underline-from-center-default hidden-xs" href="#"> <i class="rm-icon ion-android-star"></i> <span>All Collections</span> </a> </div>
</div>
</div>
</div>
</div>
</div>