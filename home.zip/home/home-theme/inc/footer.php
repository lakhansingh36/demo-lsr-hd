<div class="btm-sec">
 <footer>
 <div class="footer-top wow fadeIn" data-wow-offset="10" data-wow-duration="2s"">
 <div class="container">
 <div class="row">
 <div class="col-xs-8 col-sm-9">
 <h4><i class="ion-android-phone-portrait icon text-info"></i><span class="text-uppercase text-primary">Royal Market - fashion & multi store HTML5 theme that fits your needs from webyzona</span></h4>
 </div>
 <div class="col-xs-4 col-sm-3"> <a href="#" class="btn btn-default btn-block hvr-underline-from-center-default pull-right">Download app</a> </div>
 </div>
 </div>
 </div>
 <div class="footer-middle wow fadeIn" data-wow-offset="40" data-wow-duration="2s">
 <div class="container">
 <div class="row">
 <div class="col-md-2 col-sm-3">
 <h5 class="text-info text-uppercase">useful pages</h5>
 <ul class="list-unstyled nudge">
 <li><a href="text.html">About us</a> </li>
 <li><a href="text-left.html">Terms and conditions</a> </li>
 <li><a href="faqs.html">FAQ</a> </li>
 <li><a href="contact.html">Contact us</a> </li>
 </ul>
 <hr>
 <h5 class="text-info text-uppercase">User section</h5>
 <ul class="list-unstyled nudge">
 <li><a href="#">Login</a> </li>
 <li><a href="register.html">Regiter</a> </li>
 </ul>
 <hr class="hidden-md hidden-lg hidden-sm">
 </div>
 <div class="col-md-2 col-sm-3">
 <h5 class="text-info text-uppercase">Men</h5>
 <ul class="list-unstyled nudge">
 <li><a href="#">T-shirts</a> </li>
 <li><a href="#">Shirts</a> </li>
 <li><a href="#">Accessories</a> </li>
 <li><a href="#">Casual Dresses</a></li>
 <li><a href="#">Apparel</a></li>
 <li><a href="#">Jakets &amp; Coats</a></li>
 <li><a href="#">Formal Shoes</a></li>
 <li><a href="#">Belts</a></li>
 <li><a href="#">Blouses &amp; Shirts</a></li>
 </ul>
 </div>
 <div class="col-md-2 col-sm-3">
 <h5 class="text-info text-uppercase">Women</h5>
 <ul class="list-unstyled nudge">
 <li><a href="#">Casual Dresses</a></li>
 <li><a href="#">Apparel</a></li>
 <li><a href="#">Jakets &amp; Coats</a></li>
 <li><a href="#">Blouses &amp; Shirts</a></li>
 <li><a href="#">Skirts</a></li>
 <li><a href="#">Formal Shoes</a></li>
 <li><a href="#">Jweelery</a></li>
 <li><a href="#">Accessories</a> </li>
 <li><a href="#">Casual Dresses</a></li>
 </ul>
 </div>
 <div class="col-md-2 col-sm-3">
 <h5 class="text-info text-uppercase">juniors</h5>
 <ul class="list-unstyled nudge">
 <li><a href="#">Sunglassess</a> </li>
 <li><a href="#">Sport Shoes</a> </li>
 <li><a href="#">T-shirts</a> </li>
 <li><a href="#">Skirts</a> </li>
 <li><a href="#">Pants</a> </li>
 <li><a href="#">Accessories</a> </li>
 <li><a href="#">Sandals</a> </li>
 <li><a href="#">Accessories</a> </li>
 <li><a href="#">Apparel</a></li>
 </ul>
 </div>
 <div class="col-sm-12 col-md-4">
 <div class="row">
 <div class="col-sm-12">
 <h5 class="text-info text-uppercase">Get the news</h5>
 <p class="text-muted">Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>
 <form action="#" method="post" id="newsletter">
 <div>
 <input type="text" name="email" id="newsletter-mail" title="Sign up for our newsletter" class="input-text required-entry validate-email" placeholder="Enter your email address" autocomplete="off">
 <button type="submit" title="Subscribe" class="btn btn-primary pull-right"><span>Subscribe</span></button>
 </div>
 </form>
 <hr>
 </div>
 <div class="col-sm-12">
 <h5 class="text-info text-uppercase">Stay in touch</h5>
 <ul class="list-inline social clearfix">
 <li class="col-sm-4 facebook"><a href="#"> <span><i class="ion-social-facebook"></i></span>
 <p>2598</p>
 </a></li>
 <li class="col-sm-4 twitter"><a href="#"> <span><i class=" ion-social-twitter"></i></span>
 <p>4576</p>
 </a></li>
 <li class="col-sm-4 googleplus"><a href="#"> <span><i class=" ion-social-googleplus"></i></span>
 <p>1269</p>
 </a></li>
 </ul>
 </div>
 </div>
 </div>
 </div>
 </div>
 </div>
 
 
 <div class="footer-btm wow fadeIn" data-wow-offset="50" data-wow-duration="2s">
 <div class="container">
 <div class="row">
 <div class="col-sm-12">
 <p class="pull-left">&copy; 2016.Home Decorz </p>
 <p class="pull-right">Powered By <a class="external" href="http://www.webht.jn/">Team WebHT</a>.</p>
 </div>
 </div>
 </div>
 </div>
 </footer>
 </div>