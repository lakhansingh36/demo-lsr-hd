
<!--jQuery--> 
<script src="js/jquery.min.js"></script> 
<!--custom js--> 
<script src="js/custom.js"></script> 
<!--style switcher--> 
<script src="js/style-switcher.js"></script> 
<!--switches--> 
<script src="js/switches.js"></script> 
<!--slick carousel--> 
<script src="js/slick.js"></script> 
<!--wow animation--> 
<script src="js/wow.min.js"></script> 
<!--Bootstrap js--> 
<script src="js/bootstrap.min.js"></script> 
<!--navigation js--> 
<script src="js/jquery.highlight.js"></script> 
<script src="js/jquery.touchSwipe.min.js"></script> 
<script src="js/line.js"></script> 
<!--scrollbar js--> 
<script src="js/nicescroll.js"></script> 
<script src="js/jquery.nicescroll.plus.js"></script> 
<!--countdown counter--> 
<script src="js/countdown.js"></script> 
<!--color picker--> 
<script src="js/jquery.simplecolorpicker.js"></script> 
<!--image zoom--> 
<script src="js/jquery.zoom.js"></script> 
<!--go to top--> 
<script src='js/to-top.js'></script> 
<!--product items counter--> 
<script src="js/jquery.charactercounter.js"></script> 
<!--select--> 
<script src="js/bootstrap-select.min.js"></script> 
<!--price range slider--> 
<script src="js/bootstrap-slider.js"></script> 
<!--animated particles--> 
<script src='js/jquery.particleground.js'></script> 
<!--masonry--> 
<script src="js/salvattore.js"></script> 
<!--tab collapse--> 
<script src="js/bootstrap-tabcollapse.js"></script> 
<!--end of js-->
