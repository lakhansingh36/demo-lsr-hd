<header>
    <div class="container">
      <div class="row"> <!--start of logo-->
        <div class="col-sm-12 col-md-4 col-lg-3 "> <a href="index.php" class="navbar-brand"></a></div>
        <!--end of logo--> <!--start of features-->
        <div class="col-sm-12 col-md-8 col-lg-9 feature hidden-xs">
          <div class="row">
            <div class="col-sm-4 feature-box ion-chatbubble-working">
              <dl  class="text-primary text-capitalize">
                <dt>Online Support</dt>
                <dd class="text-muted">24/7 Etiam ultricies nis</dd>
              </dl>
            </div>
            <div class="col-sm-4 feature-box ion-android-sync">
              <dl  class="text-primary text-capitalize">
                <dt>30 Days Free Return</dt>
                <dd class="text-muted">Nullam dictum felis eu pede </dd>
              </dl>
            </div>
            <div class="col-sm-4 feature-box ion-lock-combination">
              <dl  class="text-primary text-capitalize">
                <dt>Payment Secured</dt>
                <dd class="text-muted">Lorem ipsum dolor consecteure</dd>
              </dl>
            </div>
          </div>
        </div>
        <!--end of features--> 
      </div>
    </div>
  </header>