<div id="header">
<h1><a href="#">Home Decorz Admin</a></h1>
</div>

<div id="user-nav" class="navbar navbar-inverse">
<ul class="nav">
<li><a href="#"><i class="icon-user"></i>&nbsp;My Profile</a></li>
<li class=""><a title="" href="#"><i class="icon icon-cog"></i> <span class="text">&nbsp;Settings</span></a></li>
<li class=""><a title="" href="login.html"><i class="icon icon-share-alt"></i> <span class="text">&nbsp;Logout</span></a></li>
</ul>
</div>