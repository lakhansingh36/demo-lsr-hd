<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
<ul>
<li class="active"><a href="index.html"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
<li class="submenu"> <a href="#"><i class="icon icon-info-sign"></i> <span>Categories</span> </a>
<ul>
<li><a href="add-categories.php">Update Categories</a></li>
<li><a href="all-categories.php">All Categories</a></li>
</ul>
</li>
<li class="submenu"> <a href="#"><i class="icon icon-info-sign"></i> <span>Sub Categories</span> </a>
<ul>
<li><a href="add-sub-categories.php">Update Sub Categories</a></li>
<li><a href="all-sub-categories.php">All Categories</a></li>
</ul>
</li>
<li class="submenu"> <a href="#"><i class="icon icon-fullscreen"></i><span>Products</span> </a>
<ul>
<li><a href="add-products.php">Update Products</a></li>
<li><a href="all-products.php">All Products</a></li>
</ul>
</li>
<li><a href="tables.html"><i class="icon icon-th"></i> <span>Tables</span></a></li>
</ul>
</div>