<section class="container">
<div class="row"> 
<div class="col-sm-12 big-title text-uppercase text-center">
<h3 class="text-primary">Home Decorz</h3>
<small>Maecenas nec odio et ante tincidunt tempus</small>
<p><span class="ion-android-star-outline"></span></p>
</div>
<div class="col-sm-12">
<div class="row extra-btm-padding">
<div class="col-sm-12">
<p align="center">For the past ten years, Home-Decorz based in West Hills, California, has created handmade and custom furniture. Our founder comes from a country that incorporates their heritage into their home decor. After moving to the United States, we realized that this type of home furnishings is in high demand. Our customers are looking for pieces that come with a story, and we are able to give that to them with our heritage inspired items.
</p>
<hr>

</div>
</div>
</div>
</div>
</section>